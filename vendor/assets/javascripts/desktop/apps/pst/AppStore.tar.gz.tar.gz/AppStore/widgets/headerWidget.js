define([
  "dojo/on",
  "dojo/mouse",
  "dojo/dom-class",
  "dojo/dom-construct",
  "dojo/_base/declare",
  "dojo/_base/array",
  "dijit/_WidgetBase", 
  "dijit/_TemplatedMixin",
  "dijit/Dialog",
  "dijit/form/MultiSelect",
  "dijit/form/Button",
  "/assets/desktop/src/qfacex/widgets/layout/BorderContainer",
  "dojo/text!./templates/header.html",
  "dojo/dom-style", 
  "dojo/_base/fx", 
  "dojo/_base/lang"
  ],function(on,mouse,domClass,domConstruct,declare,array,WidgetBase,TemplatedMixin,Dialog,MultiSelect,Button,BorderContainer,
    template,nlsAppStore,domStyle,baseFx,lang){
    return declare(BorderContainer,function(){
      
    })
  });