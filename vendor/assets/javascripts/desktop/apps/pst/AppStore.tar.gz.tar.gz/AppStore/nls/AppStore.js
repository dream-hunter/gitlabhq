define({ 
	root:
		({
			"search":"查找",
			"like":"赞",
			"view":"查看",
			"download":"获取",
			"add":"添加",
			"all":"全部",
			"title":"应用仓库"
		}),
	"ja": true
});
