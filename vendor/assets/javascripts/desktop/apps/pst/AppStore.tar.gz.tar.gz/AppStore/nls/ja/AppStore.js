define(
({
"search":"Search",
"like":"Like",
"view":"View",
"download":"Download"
})
);
